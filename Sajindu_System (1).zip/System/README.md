# FTTH Optical RX Power Monitor

Python backend and HTML frontend for the snapshot part of the revised Huawei NMS RX power report. The six bands are provisional triage categories. A very low reading is **not** proof of service loss, and this app does not calculate time to failure.

## Run locally

From the `System` folder in PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
$env:NMS_DB_PATH = (Join-Path (Get-Location) 'backend\data\nms.sqlite3')
Set-Location backend
..\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/`. The HTML file must be served by this backend; opening it directly from the filesystem does not provide the API. The original dashboard is preserved as `FTTH_NMS_Creative_Dashboard.legacy.html` for comparison.

## Inputs and outputs

- Upload one or more `.xlsx` workbooks (up to 20 files, 10 MB each) with exactly one worksheet and columns `Tele Numbers`, `Location`, `Power level` in that order.
- Each non-header row is accepted or rejected with an Excel row reference. Missing cells, malformed power, and identifiers or locations repeated within the same import are rejected.
- Accepted readings use the six exact boundaries in report Table 3. A `+2 dBm` value is numerically in Reference but is **not certified healthy** without the module high limit.
- The API returns source hashes, totals, counts, rejected row reasons, and accepted readings by source row. It does not return telephone identifiers or locations. The local SQLite database stores them for audit; protect the database file as customer data.
- Uploaded file contents are parsed in memory; the workbooks themselves are not stored. Separate uploads create separate imports. `latest` loads the latest import after a page refresh.

## API

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/health` | Health and policy version |
| POST | `/api/imports` | Multipart `files` upload |
| GET | `/api/imports/latest` | Latest import summary |
| GET | `/api/imports/{id}` | Import summary and source reconciliation |
| GET | `/api/imports/{id}/readings?band=very_low&limit=500&offset=0` | Accepted row references and power |
| POST | `/api/telemetry` | JSON batch of timestamped observations |
| GET | `/api/telemetry/interfaces` | Available interface IDs and sample counts |
| GET | `/api/telemetry/interfaces/{id}/analysis` | Current margins and experimental trend |
| POST | `/api/evaluate` | Evaluate independently supplied event and warning ledgers |
| GET | `/api/validation/split-plan?test_start=2026-01-29T00%3A00%3A00%2B00%3A00&folds=5&seed=42` | Group folds and forward-time purge plan |

FastAPI also provides interactive API documentation at `/docs`.

## Test

From `System\backend`:

```powershell
python -m pytest -q
```

Tests cover all report boundary examples, invalid power strings, multi-file import, rejected rows, duplicates, API privacy, frontend serving, telemetry validation, gap reset, slope time units, and event-level metric denominators. When the original workbooks are available in the parent `UPDATED` folder, an integration test also checks the full 400-row report reconciliation. The browser flow was checked with generated snapshot, telemetry, and event-ledger files.

## Experimental telemetry format

The page accepts a `.json` file in this shape:

```json
{
  "readings": [
    {
      "interface_id": "olt-1/port-1",
      "timestamp": "2026-01-01T00:00:00+05:30",
      "rx_dbm": "-25.00 dBm",
      "status": "valid",
      "sensitivity_dbm": "-35 dBm",
      "alarm_low_dbm": "-28 dBm",
      "alarm_high_dbm": "-15 dBm",
      "fault_domain": "cabinet-1"
    }
  ]
}
```

`status` is `valid`, `offline`, or `invalid`. Offline and invalid observations can omit `rx_dbm`. Timestamps must include an offset. Reimporting the same interface and timestamp updates that observation. The experimental trend uses a trailing 8-reading mean and 96 smoothed readings, fitted against elapsed days. It resets after invalid readings or gaps over 30 minutes. These are candidate settings from the report, not tuned or validated alarm parameters. The displayed seven-day crossing is a projection against the configured low alarm threshold, **not** a predicted fault or outage.

The analysis page also accepts an optional healthy mean, allowance, and decision limit for the report's one-sided lower CUSUM. All three must be supplied. Its recurrence is `C = max(0, C + healthy_mean - observed_RX - allowance)`. The displayed crossing is a candidate change signal, not a verified event. Calibrate these values from independently verified healthy training data before interpreting them.

## Event validation format

The page can evaluate independent event and consolidated warning ledgers. A minimal JSON file is:

```json
{
  "events": [
    {"event_id": "e1", "interface_id": "olt-1/port-1", "confirmed_onset": "2026-01-05T00:00:00+05:30", "static_alarm": "2026-01-05T12:00:00+05:30"}
  ],
  "episodes": [
    {"episode_id": "a1", "interface_id": "olt-1/port-1", "first_warning": "2026-01-04T12:00:00+05:30", "outcome": "evaluable"}
  ],
  "eligible_non_event_interface_days": 100
}
```

The optional exposure denominator enables unmatched episodes per 1,000 eligible non-event interface-days. Unknown episodes use `"outcome": "unknown"` and are excluded from warning precision. The evaluator returns the event and episode ledgers and a SHA-256 fingerprint of the submitted payload so results can be audited. It rejects conflicting fold or fault-group labels for an interface. Where at least two independent groups exist, it gives deterministic 95% fault-domain cluster bootstrap intervals for event recall and warning precision; otherwise the intervals are unavailable. A sample-level false-positive rate is deliberately unavailable without independent sample labels. Group and forward-time partition design must be established before using the metrics as validation evidence.

The split planner uses `fault_domain` from the telemetry records to keep related interfaces in the same held-out fold. For the forward-time test, it excludes the `horizon_days` interval immediately before `test_start` from training, then reports train, purged and test sample counts. It rejects missing or conflicting fault domains, too few groups, and a temporal split without data on both sides. The plan is reproducible from its seed and does not itself fit or test a model.

## Scope for the next stage

The report's three Excel workbooks are in the parent `UPDATED` folder. They were imported in a temporary test database: **400 accepted, 0 rejected**, with band totals **193 / 11 / 28 / 27 / 12 / 129**, exactly matching report Table 7. No workbook bytes or customer identifiers were copied into this deliverable. These workbooks have no observation timestamps or confirmed event times. The separate `FaultsAssignedToMyWG_1793184706052 data base.xlsx` has fault descriptions but no event or static-alarm timestamps, so it is not a usable validation ledger. To validate warnings in practice, obtain timestamped observations tied to stable interface IDs, device-specific limits, status/sentinel definitions, confirmed events, and the original simulation traces. The app can plan splits and evaluate supplied event and episode ledgers, but it cannot establish predictive effectiveness from the current snapshots. Live NMS ingestion also requires source-specific integration details.
