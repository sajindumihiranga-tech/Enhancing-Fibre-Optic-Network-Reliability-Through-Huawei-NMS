"""Reproducible fault-group folds and forward-time purge plans."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
import random


def plan_splits(rows: list[dict], *, folds: int, seed: int, test_start: datetime,
                horizon_days: float) -> dict:
    if test_start.utcoffset() is None:
        raise ValueError("test_start must include timezone")
    if not rows:
        raise ValueError("No telemetry available")
    groups: dict[str, set[str]] = defaultdict(set)
    interface_groups: dict[str, str] = {}
    for row in rows:
        interface = row["interface_id"]
        group = row["fault_domain"]
        if not group:
            raise ValueError(f"Missing fault_domain for interface {interface}")
        previous = interface_groups.setdefault(interface, group)
        if previous != group:
            raise ValueError(f"Conflicting fault_domain for interface {interface}")
        groups[group].add(interface)
    if len(groups) < folds:
        raise ValueError(f"Need at least {folds} distinct fault domains for {folds} folds")
    rng = random.Random(seed)
    names = sorted(groups)
    rng.shuffle(names)
    names.sort(key=lambda name: -len(groups[name]))
    fold_groups: list[list[str]] = [[] for _ in range(folds)]
    fold_sizes = [0] * folds
    for group in names:
        slot = min(range(folds), key=lambda i: (fold_sizes[i], i))
        fold_groups[slot].append(group)
        fold_sizes[slot] += len(groups[group])
    all_interfaces = set(interface_groups)
    group_folds = []
    for index, names_in_fold in enumerate(fold_groups, start=1):
        test_interfaces = sorted(interface for group in names_in_fold for interface in groups[group])
        group_folds.append({"fold": index, "test_fault_domains": sorted(names_in_fold),
                            "test_interfaces": test_interfaces,
                            "train_interfaces": sorted(all_interfaces - set(test_interfaces))})
    boundary = test_start.astimezone(timezone.utc)
    purge_start = boundary - timedelta(days=horizon_days)
    counts = Counter()
    per_interface = defaultdict(Counter)
    for row in rows:
        timestamp = datetime.fromisoformat(row["observed_at"]).astimezone(timezone.utc)
        partition = "train" if timestamp < purge_start else "purged" if timestamp < boundary else "test"
        counts[partition] += 1
        per_interface[row["interface_id"]][partition] += 1
    if not counts["train"] or not counts["test"]:
        raise ValueError("Forward-time split needs observations before purge and on or after test_start")
    return {
        "seed": seed, "folds": group_folds,
        "forward_time": {"test_start": boundary.isoformat(), "purge_start": purge_start.isoformat(),
                         "horizon_days": horizon_days, "train_samples": counts["train"],
                         "purged_samples": counts["purged"], "test_samples": counts["test"],
                         "per_interface": {key: dict(value) for key, value in sorted(per_interface.items())}},
        "notice": "This is a partition plan only. Tune on training data; keep each held-out fold untouched and evaluate later time periods separately.",
    }
