"""Event-level evaluation of independently supplied warning and fault ledgers."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timedelta
from hashlib import sha256
import random
from statistics import mean, median

from pydantic import BaseModel, Field, model_validator


class ConfirmedEvent(BaseModel):
    event_id: str = Field(min_length=1)
    interface_id: str = Field(min_length=1)
    confirmed_onset: datetime
    static_alarm: datetime | None = None
    service_impact: datetime | None = None
    recovery: datetime | None = None
    fold: str | None = None
    fault_group: str | None = None

    @model_validator(mode="after")
    def timestamps_valid(self):
        for name in ("confirmed_onset", "static_alarm", "service_impact", "recovery"):
            value = getattr(self, name)
            if value is not None and value.utcoffset() is None:
                raise ValueError(f"{name} needs a timezone")
        if self.recovery is not None and self.recovery < self.confirmed_onset:
            raise ValueError("recovery precedes event onset")
        return self


class WarningEpisode(BaseModel):
    episode_id: str = Field(min_length=1)
    interface_id: str = Field(min_length=1)
    first_warning: datetime
    last_warning: datetime | None = None
    outcome: str = Field(pattern="^(evaluable|unknown)$")
    fold: str | None = None

    @model_validator(mode="after")
    def timestamps_valid(self):
        if self.first_warning.utcoffset() is None:
            raise ValueError("first_warning needs a timezone")
        if self.last_warning is not None:
            if self.last_warning.utcoffset() is None or self.last_warning < self.first_warning:
                raise ValueError("last_warning needs a timezone and cannot precede first_warning")
        return self


class EvaluationInput(BaseModel):
    events: list[ConfirmedEvent]
    episodes: list[WarningEpisode]
    eligible_non_event_interface_days: float | None = Field(default=None, gt=0)
    horizon_days: float = Field(default=7, gt=0, le=30)

    @model_validator(mode="after")
    def unique_ids(self):
        if len({item.event_id for item in self.events}) != len(self.events):
            raise ValueError("Duplicate event_id")
        if len({item.episode_id for item in self.episodes}) != len(self.episodes):
            raise ValueError("Duplicate episode_id")
        folds_by_interface: dict[str, set[str]] = {}
        for item in [*self.events, *self.episodes]:
            if item.fold is not None:
                folds_by_interface.setdefault(item.interface_id, set()).add(item.fold)
        inconsistent = [interface for interface, folds in folds_by_interface.items() if len(folds) > 1]
        if inconsistent:
            raise ValueError(f"Conflicting fold labels for interface {inconsistent[0]}")
        groups_by_interface: dict[str, set[str]] = {}
        for event in self.events:
            if event.fault_group is not None:
                groups_by_interface.setdefault(event.interface_id, set()).add(event.fault_group)
        inconsistent_groups = [interface for interface, groups in groups_by_interface.items() if len(groups) > 1]
        if inconsistent_groups:
            raise ValueError(f"Conflicting fault groups for interface {inconsistent_groups[0]}")
        return self


def evaluate(data: EvaluationInput) -> dict:
    """Match evaluable episodes to the earliest later event on the same interface."""
    horizon = timedelta(days=data.horizon_days)
    matches: dict[str, list[WarningEpisode]] = {event.event_id: [] for event in data.events}
    episode_ledger = []
    matched_episodes = 0
    unmatched_episodes = 0
    unknown_episodes = 0
    for episode in data.episodes:
        if episode.outcome == "unknown":
            unknown_episodes += 1
            episode_ledger.append({"episode_id": episode.episode_id, "matched_event_id": None, "outcome": "unknown"})
            continue
        candidates = [event for event in data.events if event.interface_id == episode.interface_id
                      and episode.first_warning <= event.confirmed_onset <= episode.first_warning + horizon]
        chosen = min(candidates, key=lambda event: event.confirmed_onset) if candidates else None
        if chosen:
            matches[chosen.event_id].append(episode)
            matched_episodes += 1
        else:
            unmatched_episodes += 1
        episode_ledger.append({"episode_id": episode.episode_id,
                               "matched_event_id": chosen.event_id if chosen else None,
                               "outcome": "matched" if chosen else "unmatched"})
    event_ledger = []
    early = late = missed = 0
    lead_hours = []
    eligible = 0
    for event in data.events:
        warnings = matches[event.event_id]
        first = min((item.first_warning for item in warnings), default=None)
        if event.static_alarm is None:
            outcome = "no_static_baseline"
        else:
            eligible += 1
            if first is None:
                outcome = "missed"
                missed += 1
            else:
                lead = (event.static_alarm - first).total_seconds() / 3600
                lead_hours.append(lead)
                if lead > 0:
                    outcome = "early"
                    early += 1
                else:
                    outcome = "late"
                    late += 1
        event_ledger.append({"event_id": event.event_id, "interface_id": event.interface_id,
                             "fold": event.fold, "fault_group": event.fault_group,
                             "first_warning": first.isoformat() if first else None,
                             "static_alarm": event.static_alarm.isoformat() if event.static_alarm else None,
                             "outcome": outcome})
    evaluable_episodes = matched_episodes + unmatched_episodes
    group_by_interface = {event.interface_id: event.fault_group or event.interface_id for event in data.events}
    cluster_stats = defaultdict(Counter)
    for event, row in zip(data.events, event_ledger):
        if event.static_alarm is not None:
            group = group_by_interface[event.interface_id]
            cluster_stats[group]["eligible"] += 1
            cluster_stats[group]["early"] += row["outcome"] == "early"
    for episode, row in zip(data.episodes, episode_ledger):
        if episode.outcome == "evaluable":
            group = group_by_interface.get(episode.interface_id, episode.interface_id)
            cluster_stats[group]["evaluable"] += 1
            cluster_stats[group]["matched"] += row["outcome"] == "matched"

    def interval(numerator: str, denominator: str) -> dict | None:
        groups = sorted(cluster_stats)
        if len(groups) < 2:
            return None
        rng = random.Random(42)
        ratios = []
        for _ in range(1000):
            selected = [rng.choice(groups) for _ in groups]
            den = sum(cluster_stats[group][denominator] for group in selected)
            if den:
                ratios.append(sum(cluster_stats[group][numerator] for group in selected) / den)
        if len(ratios) < 100:
            return None
        ratios.sort()
        return {"method": "fault-domain cluster bootstrap", "clusters": len(groups),
                "valid_resamples": len(ratios), "seed": 42,
                "lower_95": ratios[int(0.025 * (len(ratios)-1))],
                "upper_95": ratios[int(0.975 * (len(ratios)-1))]}

    return {
        "input_sha256": sha256(data.model_dump_json().encode("utf-8")).hexdigest(),
        "events": len(data.events), "eligible_events": eligible,
        "early_events": early, "late_events": late, "missed_events": missed,
        "early_event_recall": early / eligible if eligible else None,
        "evaluable_episodes": evaluable_episodes, "matched_episodes": matched_episodes,
        "unmatched_episodes": unmatched_episodes, "unknown_episodes": unknown_episodes,
        "warning_precision": matched_episodes / evaluable_episodes if evaluable_episodes else None,
        "early_recall_interval": interval("early", "eligible"),
        "warning_precision_interval": interval("matched", "evaluable"),
        "lead_time_hours": {"count": len(lead_hours), "mean": mean(lead_hours),
                            "median": median(lead_hours), "min": min(lead_hours), "max": max(lead_hours)} if lead_hours else None,
        "unmatched_episodes_per_1000_interface_days":
            1000 * unmatched_episodes / data.eligible_non_event_interface_days
            if data.eligible_non_event_interface_days else None,
        "sample_false_positive_rate": None,
        "event_ledger": event_ledger, "episode_ledger": episode_ledger,
        "notice": "Metrics describe supplied independent ledgers only. Unknown outcomes are separate; no sample false-positive rate is inferred.",
    }
