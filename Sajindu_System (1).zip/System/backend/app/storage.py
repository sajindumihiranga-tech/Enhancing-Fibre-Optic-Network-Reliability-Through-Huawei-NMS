"""Small SQLite store. Raw identifiers stay server side and never enter dashboard JSON."""
from __future__ import annotations

import os
from pathlib import Path
import sqlite3


def db_path() -> Path:
    return Path(os.environ.get("NMS_DB_PATH", Path(__file__).resolve().parents[1] / "data" / "nms.sqlite3"))


def connect() -> sqlite3.Connection:
    path = db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript("""
    CREATE TABLE IF NOT EXISTS imports (
      id INTEGER PRIMARY KEY, created_at TEXT NOT NULL, policy_version TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sources (
      id INTEGER PRIMARY KEY, import_id INTEGER NOT NULL REFERENCES imports(id),
      filename TEXT NOT NULL, sheet TEXT NOT NULL, sha256 TEXT NOT NULL,
      total_rows INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS readings (
      id INTEGER PRIMARY KEY, source_id INTEGER NOT NULL REFERENCES sources(id),
      excel_row INTEGER NOT NULL, identifier TEXT, location TEXT, raw_power TEXT,
      rx_dbm TEXT, band TEXT, error TEXT
    );
    CREATE INDEX IF NOT EXISTS readings_source_idx ON readings(source_id);
    CREATE TABLE IF NOT EXISTS telemetry (
      id INTEGER PRIMARY KEY, interface_id TEXT NOT NULL, observed_at TEXT NOT NULL,
      rx_dbm TEXT, status TEXT NOT NULL, sensitivity_dbm TEXT,
      alarm_low_dbm TEXT, alarm_high_dbm TEXT, fault_domain TEXT,
      UNIQUE(interface_id, observed_at)
    );
    CREATE INDEX IF NOT EXISTS telemetry_interface_time_idx ON telemetry(interface_id, observed_at);
    """)
    return db
