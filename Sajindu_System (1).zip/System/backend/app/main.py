"""FTTH RX power snapshot API and static frontend."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .core import BANDS, ParsedRow, parse_workbook
from .storage import connect
from .monitoring import Observation, analyze, utc_iso
from .evaluation import EvaluationInput, evaluate
from .splits import plan_splits

MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_FILES = 20
POLICY_VERSION = "report-table-3-v1"
FRONTEND = Path(__file__).resolve().parents[2] / "FTTH_NMS_Creative_Dashboard.html"
app = FastAPI(title="FTTH RX Power Monitor", version="1.0.0")


@app.get("/")
def home():
    return FileResponse(FRONTEND)


@app.get("/api/health")
def health():
    return {"status": "ok", "policy_version": POLICY_VERSION}


def _summary(db, import_id: int) -> dict:
    record = db.execute("SELECT * FROM imports WHERE id=?", (import_id,)).fetchone()
    if record is None:
        raise HTTPException(404, "Import not found")
    source_rows = db.execute("SELECT * FROM sources WHERE import_id=? ORDER BY id", (import_id,)).fetchall()
    sources = []
    total_counts = Counter()
    rejected = 0
    total_rows = 0
    for source in source_rows:
        counts = Counter({name: 0 for name in BANDS})
        errors = []
        for row in db.execute("SELECT excel_row, band, error FROM readings WHERE source_id=? ORDER BY excel_row", (source["id"],)):
            if row["error"]:
                errors.append({"excel_row": row["excel_row"], "reason": row["error"]})
            else:
                counts[row["band"]] += 1
        count = source["total_rows"]
        accepted = sum(counts.values())
        total_rows += count
        rejected += len(errors)
        total_counts.update(counts)
        sources.append({
            "id": source["id"], "filename": source["filename"], "sheet": source["sheet"],
            "sha256": source["sha256"], "total_rows": count, "accepted": accepted,
            "rejected": len(errors), "counts": dict(counts), "errors": errors,
        })
    return {
        "id": import_id, "created_at": record["created_at"], "policy_version": record["policy_version"],
        "total_rows": total_rows, "accepted": sum(total_counts.values()), "rejected": rejected,
        "counts": {name: total_counts[name] for name in BANDS}, "sources": sources,
        "notice": "Provisional triage bands. Very low does not prove service loss; measurement status and module limits are unverified.",
    }


@app.post("/api/imports", status_code=201)
async def create_import(files: list[UploadFile] = File(...)):
    if not files or len(files) > MAX_FILES:
        raise HTTPException(400, f"Upload 1 to {MAX_FILES} workbooks")
    prepared: list[tuple[str, str, str, list[ParsedRow]]] = []
    for file in files:
        name = Path(file.filename or "").name
        if not name.lower().endswith(".xlsx"):
            raise HTTPException(400, f"{name}: only .xlsx files are supported")
        content = await file.read(MAX_FILE_BYTES + 1)
        if len(content) > MAX_FILE_BYTES:
            raise HTTPException(413, f"{name}: file exceeds 10 MB")
        try:
            sheet, rows = parse_workbook(content)
        except ValueError as exc:
            raise HTTPException(422, f"{name}: {exc}") from exc
        prepared.append((name, sheet, sha256(content).hexdigest(), rows))

    db = connect()
    try:
        with db:
            cur = db.execute("INSERT INTO imports(created_at, policy_version) VALUES (?, ?)",
                             (datetime.now(timezone.utc).isoformat(), POLICY_VERSION))
            import_id = cur.lastrowid
            seen_ids: set[str] = set()
            seen_locations: set[str] = set()
            for name, sheet, fingerprint, rows in prepared:
                cur = db.execute("INSERT INTO sources(import_id, filename, sheet, sha256, total_rows) VALUES (?, ?, ?, ?, ?)",
                                 (import_id, name, sheet, fingerprint, len(rows)))
                source_id = cur.lastrowid
                for row in rows:
                    error = row.error
                    if not error:
                        if row.identifier in seen_ids:
                            error = "Duplicate identifier within this import"
                        elif row.location in seen_locations:
                            error = "Duplicate location within this import"
                        else:
                            seen_ids.add(row.identifier)
                            seen_locations.add(row.location)
                    db.execute("""INSERT INTO readings(source_id, excel_row, identifier, location, raw_power, rx_dbm, band, error)
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                               (source_id, row.excel_row, row.identifier, row.location, row.raw_power,
                                str(row.power) if row.power is not None else None, row.band if not error else None, error))
        return _summary(db, import_id)
    finally:
        db.close()


@app.get("/api/imports/latest")
def latest_import():
    db = connect()
    try:
        row = db.execute("SELECT id FROM imports ORDER BY id DESC LIMIT 1").fetchone()
        return {"import": _summary(db, row["id"]) if row else None}
    finally:
        db.close()


@app.get("/api/imports/{import_id}")
def get_import(import_id: int):
    db = connect()
    try:
        return _summary(db, import_id)
    finally:
        db.close()


@app.get("/api/imports/{import_id}/readings")
def get_readings(import_id: int, band: str | None = None, limit: int = 500, offset: int = 0):
    """Expose source references and power, without telephone identifiers or locations."""
    if band is not None and band not in BANDS:
        raise HTTPException(400, "Unknown band")
    if not 1 <= limit <= 1000 or offset < 0:
        raise HTTPException(400, "Invalid pagination")
    db = connect()
    try:
        if not db.execute("SELECT 1 FROM imports WHERE id=?", (import_id,)).fetchone():
            raise HTTPException(404, "Import not found")
        query = """FROM readings r JOIN sources s ON s.id=r.source_id
                   WHERE s.import_id=? AND r.error IS NULL"""
        args: list = [import_id]
        if band:
            query += " AND r.band=?"
            args.append(band)
        total = db.execute("SELECT COUNT(*) " + query, args).fetchone()[0]
        rows = db.execute("""SELECT s.filename, s.sheet, r.excel_row, r.rx_dbm, r.band """ + query +
                          " ORDER BY s.id, r.excel_row LIMIT ? OFFSET ?", [*args, limit, offset]).fetchall()
        return {"total": total, "limit": limit, "offset": offset, "readings": [dict(row) for row in rows]}
    finally:
        db.close()


class TelemetryBatch(BaseModel):
    readings: list[Observation] = Field(min_length=1, max_length=10000)


@app.post("/api/telemetry", status_code=201)
def ingest_telemetry(batch: TelemetryBatch):
    """Idempotently ingest timestamped, status-labelled data for a future pilot."""
    db = connect()
    try:
        with db:
            for item in batch.readings:
                db.execute("""INSERT INTO telemetry(interface_id, observed_at, rx_dbm, status,
                              sensitivity_dbm, alarm_low_dbm, alarm_high_dbm, fault_domain)
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                              ON CONFLICT(interface_id, observed_at) DO UPDATE SET
                              rx_dbm=excluded.rx_dbm, status=excluded.status,
                              sensitivity_dbm=excluded.sensitivity_dbm,
                              alarm_low_dbm=excluded.alarm_low_dbm,
                              alarm_high_dbm=excluded.alarm_high_dbm,
                              fault_domain=excluded.fault_domain""",
                           (item.interface_id, utc_iso(item.timestamp), item.rx_dbm, item.status,
                            item.sensitivity_dbm, item.alarm_low_dbm, item.alarm_high_dbm, item.fault_domain))
        return {"ingested": len(batch.readings), "interfaces": sorted({item.interface_id for item in batch.readings}),
                "notice": "Data stored for experimental analysis only; no event validation is implied."}
    finally:
        db.close()


@app.get("/api/telemetry/interfaces")
def list_interfaces():
    db = connect()
    try:
        rows = db.execute("SELECT interface_id, COUNT(*) AS observations, MAX(observed_at) AS latest_timestamp FROM telemetry GROUP BY interface_id ORDER BY interface_id").fetchall()
        return {"interfaces": [dict(row) for row in rows]}
    finally:
        db.close()


@app.get("/api/telemetry/interfaces/{interface_id}/analysis")
def interface_analysis(interface_id: str,
                       reference_mean_dbm: float | None = None,
                       allowance_db: float | None = Query(default=None, ge=0),
                       decision_limit_db: float | None = Query(default=None, gt=0)):
    provided = [reference_mean_dbm is not None, allowance_db is not None, decision_limit_db is not None]
    if any(provided) and not all(provided):
        raise HTTPException(400, "Supply reference_mean_dbm, allowance_db, and decision_limit_db together")
    if reference_mean_dbm is not None:
        import math
        if not all(math.isfinite(value) for value in (reference_mean_dbm, allowance_db, decision_limit_db)):
            raise HTTPException(400, "CUSUM parameters must be finite")
    db = connect()
    try:
        rows = [dict(row) for row in db.execute("""SELECT observed_at, rx_dbm, status, sensitivity_dbm,
                            alarm_low_dbm, alarm_high_dbm FROM telemetry WHERE interface_id=?
                            ORDER BY observed_at""", (interface_id,))]
        if not rows:
            raise HTTPException(404, "Interface not found")
        return {"interface_id": interface_id, **analyze(rows, reference_mean_dbm=reference_mean_dbm,
            allowance_db=allowance_db, decision_limit_db=decision_limit_db)}
    finally:
        db.close()


@app.post("/api/evaluate")
def evaluate_ledgers(data: EvaluationInput):
    return evaluate(data)


@app.get("/api/validation/split-plan")
def validation_split_plan(test_start: datetime, folds: int = Query(default=5, ge=2, le=10),
                          seed: int = 42, horizon_days: float = Query(default=7, gt=0, le=30)):
    db = connect()
    try:
        rows = [dict(row) for row in db.execute("SELECT interface_id, observed_at, fault_domain FROM telemetry ORDER BY interface_id, observed_at")]
    finally:
        db.close()
    try:
        return plan_splits(rows, folds=folds, seed=seed, test_start=test_start, horizon_days=horizon_days)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
