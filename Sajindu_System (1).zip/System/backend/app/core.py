"""Auditable snapshot parsing and the provisional policy from report Table 3."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from io import BytesIO
import re

from openpyxl import load_workbook

HEADERS = ("Tele Numbers", "Location", "Power level")
POWER_RE = re.compile(r"([+-]?(?:\d+(?:\.\d*)?|\.\d+))\s*dBm", re.IGNORECASE)
BANDS = ("reference", "buffer", "watch", "priority", "urgent", "very_low")


def parse_power(value: object) -> Decimal:
    match = POWER_RE.fullmatch(str(value).strip())
    if not match:
        raise ValueError("Power must be a complete numeric value followed by dBm")
    try:
        power = Decimal(match.group(1))
    except InvalidOperation as exc:
        raise ValueError("Invalid numeric power") from exc
    if not power.is_finite():
        raise ValueError("Non-finite power")
    return power


def band_for(power: Decimal) -> str:
    if power >= -25:
        return "reference"
    if power >= -27:
        return "buffer"
    if power > -30:
        return "watch"
    if power > -34:
        return "priority"
    if power >= -38:
        return "urgent"
    return "very_low"


@dataclass(frozen=True)
class ParsedRow:
    sheet: str
    excel_row: int
    identifier: str
    location: str
    raw_power: str
    power: Decimal | None
    band: str | None
    error: str | None


def parse_workbook(content: bytes) -> tuple[str, list[ParsedRow]]:
    try:
        book = load_workbook(BytesIO(content), read_only=True, data_only=True)
    except Exception as exc:
        raise ValueError("File is not a readable .xlsx workbook") from exc
    try:
        if len(book.worksheets) != 1:
            raise ValueError("Expected exactly one worksheet")
        sheet = book.worksheets[0]
        rows = sheet.iter_rows(values_only=True)
        header = next(rows, None)
        if header is None or tuple(header) != HEADERS:
            raise ValueError("Expected columns: Tele Numbers, Location, Power level")
        parsed: list[ParsedRow] = []
        for row_number, values in enumerate(rows, start=2):
            if len(values) != 3:
                parsed.append(ParsedRow(sheet.title, row_number, "", "", "", None, None, "Expected exactly three cells"))
                continue
            identifier, location, raw = values
            identifier_text = str(identifier).strip() if identifier is not None else ""
            location_text = str(location).strip() if location is not None else ""
            raw_text = str(raw).strip() if raw is not None else ""
            if not identifier_text or not location_text:
                parsed.append(ParsedRow(sheet.title, row_number, identifier_text, location_text, raw_text, None, None, "Missing identifier or location"))
                continue
            try:
                power = parse_power(raw_text)
            except ValueError as exc:
                parsed.append(ParsedRow(sheet.title, row_number, identifier_text, location_text, raw_text, None, None, str(exc)))
                continue
            parsed.append(ParsedRow(sheet.title, row_number, identifier_text, location_text, raw_text, power, band_for(power), None))
        return sheet.title, parsed
    finally:
        book.close()
