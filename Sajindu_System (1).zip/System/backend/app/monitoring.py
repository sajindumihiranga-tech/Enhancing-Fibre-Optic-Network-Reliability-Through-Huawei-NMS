"""Experimental causal trend analysis specified in report Appendix B."""
from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from statistics import mean

from pydantic import BaseModel, Field, field_validator, model_validator

from .core import parse_power


class Observation(BaseModel):
    interface_id: str = Field(min_length=1, max_length=100)
    timestamp: datetime
    rx_dbm: str | None = None
    status: str = Field(pattern="^(valid|offline|invalid)$")
    sensitivity_dbm: str | None = None
    alarm_low_dbm: str | None = None
    alarm_high_dbm: str | None = None
    fault_domain: str | None = Field(default=None, max_length=100)

    @field_validator("interface_id")
    @classmethod
    def strip_interface(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("interface_id is empty")
        return value

    @model_validator(mode="after")
    def valid_fields(self):
        if self.timestamp.tzinfo is None or self.timestamp.utcoffset() is None:
            raise ValueError("timestamp must include timezone")
        if self.status == "valid" and self.rx_dbm is None:
            raise ValueError("valid observation requires rx_dbm")
        for field in ("rx_dbm", "sensitivity_dbm", "alarm_low_dbm", "alarm_high_dbm"):
            value = getattr(self, field)
            if value is not None:
                parse_power(value)
        if self.alarm_low_dbm is not None and self.alarm_high_dbm is not None:
            if parse_power(self.alarm_low_dbm) >= parse_power(self.alarm_high_dbm):
                raise ValueError("alarm_low_dbm must be below alarm_high_dbm")
        return self


def utc_iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat()


def analyze(rows: list[dict], *, max_gap_minutes: int = 30,
            reference_mean_dbm: float | None = None, allowance_db: float | None = None,
            decision_limit_db: float | None = None) -> dict:
    """Only earlier valid samples are used; a gap or invalid sample resets windows."""
    if not rows:
        return {"status": "no_data", "observations": 0, "trend": None}
    valid: list[tuple[datetime, float]] = []
    last = rows[-1]
    for row in rows:
        timestamp = datetime.fromisoformat(row["observed_at"])
        if row["status"] != "valid" or row["rx_dbm"] is None:
            valid.clear()
            continue
        if valid and (timestamp - valid[-1][0]).total_seconds() > max_gap_minutes * 60:
            valid.clear()
        valid.append((timestamp, float(parse_power(row["rx_dbm"]))))
    result = {
        "status": "experimental", "observations": len(rows), "consecutive_valid": len(valid),
        "latest_timestamp": last["observed_at"], "latest_status": last["status"],
        "rx_dbm": str(parse_power(last["rx_dbm"])) if last["status"] == "valid" and last["rx_dbm"] else None,
        "receiver_headroom_db": None, "alarm_headroom_db": None,
        "high_limit_margin_db": None, "trend": None, "cusum": None,
        "notice": "Trend is an experimental arithmetic signal, not a validated failure prediction.",
    }
    if last["status"] != "valid" or not last["rx_dbm"]:
        return result
    if reference_mean_dbm is not None and allowance_db is not None and decision_limit_db is not None:
        cumulative = 0.0
        first_crossing = None
        for timestamp, power in valid:
            cumulative = max(0.0, cumulative + reference_mean_dbm - power - allowance_db)
            if first_crossing is None and cumulative > decision_limit_db:
                first_crossing = timestamp.isoformat()
        result["cusum"] = {
            "reference_mean_dbm": reference_mean_dbm,
            "allowance_db": allowance_db,
            "decision_limit_db": decision_limit_db,
            "current_cumulative_db": round(cumulative, 6),
            "crossed_limit": first_crossing is not None,
            "first_crossing": first_crossing,
            "notice": "Candidate lower CUSUM only. Reference and thresholds must come from verified healthy training data.",
        }
    current = parse_power(last["rx_dbm"])
    if last["sensitivity_dbm"]:
        result["receiver_headroom_db"] = str(current - parse_power(last["sensitivity_dbm"]))
    if last["alarm_low_dbm"]:
        result["alarm_headroom_db"] = str(current - parse_power(last["alarm_low_dbm"]))
    if last["alarm_high_dbm"]:
        result["high_limit_margin_db"] = str(parse_power(last["alarm_high_dbm"]) - current)
    # 96 smoothed observations require 103 raw observations (8 for first mean).
    if len(valid) < 103:
        return result
    smoothed = [(valid[i][0], mean(value for _, value in valid[i-7:i+1]))
                for i in range(7, len(valid))]
    window = smoothed[-96:]
    origin = window[0][0]
    days = [(time - origin).total_seconds() / 86400 for time, _ in window]
    values = [value for _, value in window]
    mx, my = mean(days), mean(values)
    denominator = sum((day-mx)**2 for day in days)
    if denominator == 0:
        return result
    slope = sum((day-mx)*(value-my) for day, value in zip(days, values)) / denominator
    projected = values[-1] + slope * 7
    low = float(parse_power(last["alarm_low_dbm"])) if last["alarm_low_dbm"] else None
    result["trend"] = {
        "slope_db_per_day": round(slope, 6), "smoothed_rx_dbm": round(values[-1], 6),
        "projected_7d_dbm": round(projected, 6),
        "crosses_low_alarm_7d": bool(low is not None and slope < 0 and float(current) > low and projected <= low),
        "window_start": window[0][0].isoformat(), "window_end": window[-1][0].isoformat(),
        "sample_count": 96,
    }
    return result
