from fastapi.testclient import TestClient
import pytest

from app.main import app


def event(event_id, interface, onset, alarm=None):
    return {"event_id": event_id, "interface_id": interface,
            "confirmed_onset": onset, "static_alarm": alarm}


def episode(episode_id, interface, warning, outcome="evaluable"):
    return {"episode_id": episode_id, "interface_id": interface,
            "first_warning": warning, "outcome": outcome}


def test_event_and_episode_metrics_use_correct_denominators():
    client = TestClient(app)
    data = {
        "events": [
            event("e1", "a", "2026-01-05T00:00:00+00:00", "2026-01-05T12:00:00+00:00"),
            event("e2", "b", "2026-01-08T00:00:00+00:00", "2026-01-06T00:00:00+00:00"),
            event("e3", "c", "2026-01-10T00:00:00+00:00", "2026-01-10T01:00:00+00:00"),
        ],
        "episodes": [
            episode("a1", "a", "2026-01-04T12:00:00+00:00"),
            episode("b1", "b", "2026-01-07T00:00:00+00:00"),
            episode("x1", "x", "2026-01-04T00:00:00+00:00"),
            episode("u1", "a", "2026-01-04T13:00:00+00:00", "unknown"),
        ],
        "eligible_non_event_interface_days": 100,
    }
    response = client.post("/api/evaluate", json=data)
    assert response.status_code == 200
    result = response.json()
    assert (result["early_events"], result["late_events"], result["missed_events"]) == (1, 1, 1)
    assert result["early_event_recall"] == pytest.approx(1/3)
    assert (result["matched_episodes"], result["unmatched_episodes"], result["unknown_episodes"]) == (2, 1, 1)
    assert result["warning_precision"] == pytest.approx(2/3)
    assert result["unmatched_episodes_per_1000_interface_days"] == 10
    assert result["lead_time_hours"]["count"] == 2
    assert result["lead_time_hours"]["min"] == -24
    assert result["lead_time_hours"]["max"] == 24
    assert result["sample_false_positive_rate"] is None
    assert result["early_recall_interval"]["method"] == "fault-domain cluster bootstrap"
    assert 0 <= result["early_recall_interval"]["lower_95"] <= result["early_event_recall"] <= result["early_recall_interval"]["upper_95"] <= 1


def test_horizon_and_timezone_validation():
    client = TestClient(app)
    data = {"events": [event("e1", "a", "2026-01-10T00:00:00+00:00", "2026-01-10T01:00:00+00:00")],
            "episodes": [episode("a1", "a", "2026-01-01T00:00:00+00:00")]}
    result = client.post("/api/evaluate", json=data).json()
    assert result["unmatched_episodes"] == 1
    assert result["missed_events"] == 1
    data["events"][0]["confirmed_onset"] = "2026-01-10T00:00:00"
    assert client.post("/api/evaluate", json=data).status_code == 422


def test_empty_and_duplicate_ledgers():
    client = TestClient(app)
    result = client.post("/api/evaluate", json={"events": [], "episodes": []}).json()
    assert result["early_event_recall"] is None
    assert result["warning_precision"] is None
    assert result["early_recall_interval"] is None
    item = event("e1", "a", "2026-01-10T00:00:00+00:00")
    assert client.post("/api/evaluate", json={"events": [item, item], "episodes": []}).status_code == 422


def test_conflicting_fold_labels_rejected_and_input_hash_stable():
    client = TestClient(app)
    payload = {
        "events": [{**event("e1", "a", "2026-01-10T00:00:00+00:00"), "fold": "fold-1"}],
        "episodes": [{**episode("a1", "a", "2026-01-09T00:00:00+00:00"), "fold": "fold-2"}],
    }
    assert client.post("/api/evaluate", json=payload).status_code == 422
    payload["episodes"][0]["fold"] = "fold-1"
    first = client.post("/api/evaluate", json=payload).json()
    second = client.post("/api/evaluate", json=payload).json()
    assert first["input_sha256"] == second["input_sha256"]
    assert first["early_recall_interval"] is None


def test_conflicting_fault_groups_rejected():
    client = TestClient(app)
    a = {**event("e1", "a", "2026-01-10T00:00:00+00:00"), "fault_group": "cabinet-1"}
    b = {**event("e2", "a", "2026-01-12T00:00:00+00:00"), "fault_group": "cabinet-2"}
    assert client.post("/api/evaluate", json={"events": [a, b], "episodes": []}).status_code == 422
