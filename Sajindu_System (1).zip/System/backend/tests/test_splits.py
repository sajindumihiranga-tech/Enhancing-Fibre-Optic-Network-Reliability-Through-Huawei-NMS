from datetime import datetime, timedelta, timezone

from fastapi.testclient import TestClient
import pytest

from app.main import app
from app.splits import plan_splits


def rows():
    start = datetime(2026, 1, 20, tzinfo=timezone.utc)
    return [{"interface_id": f"if-{i}", "fault_domain": f"group-{i//2}",
             "observed_at": (start + timedelta(days=day)).isoformat()}
            for i in range(10) for day in (0, 5, 10)]


def test_group_folds_and_forward_purge_are_disjoint():
    result = plan_splits(rows(), folds=5, seed=19,
                         test_start=datetime(2026, 1, 29, tzinfo=timezone.utc), horizon_days=7)
    assert len(result["folds"]) == 5
    all_test = []
    for fold in result["folds"]:
        assert set(fold["test_interfaces"]).isdisjoint(fold["train_interfaces"])
        assert len(fold["test_fault_domains"]) == 1
        assert len(fold["test_interfaces"]) == 2
        all_test.extend(fold["test_interfaces"])
    assert sorted(all_test) == [f"if-{i}" for i in range(10)]
    assert result["forward_time"]["train_samples"] == 10
    assert result["forward_time"]["purged_samples"] == 10
    assert result["forward_time"]["test_samples"] == 10
    assert result == plan_splits(rows(), folds=5, seed=19,
                                 test_start=datetime(2026, 1, 29, tzinfo=timezone.utc), horizon_days=7)


def test_missing_or_conflicting_fault_domain_rejected():
    sample = rows()
    sample[0]["fault_domain"] = None
    with pytest.raises(ValueError, match="Missing fault_domain"):
        plan_splits(sample, folds=5, seed=1, test_start=datetime(2026, 1, 29, tzinfo=timezone.utc), horizon_days=7)
    sample = rows()
    sample[0]["fault_domain"] = "different"
    with pytest.raises(ValueError, match="Conflicting fault_domain"):
        plan_splits(sample, folds=5, seed=1, test_start=datetime(2026, 1, 29, tzinfo=timezone.utc), horizon_days=7)


def test_api_plan_from_ingested_telemetry(tmp_path, monkeypatch):
    monkeypatch.setenv("NMS_DB_PATH", str(tmp_path / "split.sqlite3"))
    client = TestClient(app)
    payload = {"readings": [{"interface_id": row["interface_id"], "timestamp": row["observed_at"],
                             "rx_dbm": "-25 dBm", "status": "valid", "fault_domain": row["fault_domain"]}
                            for row in rows()]}
    assert client.post("/api/telemetry", json=payload).status_code == 201
    response = client.get("/api/validation/split-plan?test_start=2026-01-29T00:00:00%2B00:00&folds=5&seed=19")
    assert response.status_code == 200
    assert response.json()["forward_time"]["purged_samples"] == 10


def test_plan_requires_both_temporal_sides():
    with pytest.raises(ValueError, match="before purge"):
        plan_splits(rows(), folds=5, seed=1,
                    test_start=datetime(2026, 1, 1, tzinfo=timezone.utc), horizon_days=7)
