from datetime import datetime, timedelta, timezone

from fastapi.testclient import TestClient
import pytest

from app.main import app


@pytest.fixture(autouse=True)
def database(tmp_path, monkeypatch):
    monkeypatch.setenv("NMS_DB_PATH", str(tmp_path / "test.sqlite3"))


def series(count=103, *, interface="if-1", step=-0.01, start=None):
    start = start or datetime(2026, 1, 1, tzinfo=timezone.utc)
    return [{
        "interface_id": interface, "timestamp": (start + timedelta(minutes=15*i)).isoformat(),
        "rx_dbm": f"{(-25 + step*i):.4f} dBm", "status": "valid",
        "sensitivity_dbm": "-35 dBm", "alarm_low_dbm": "-28 dBm",
        "alarm_high_dbm": "-15 dBm", "fault_domain": "group-1",
    } for i in range(count)]


def test_trend_uses_days_and_margins():
    client = TestClient(app)
    readings = series()
    assert client.post("/api/telemetry", json={"readings": readings}).status_code == 201
    data = client.get("/api/telemetry/interfaces/if-1/analysis").json()
    assert data["consecutive_valid"] == 103
    assert data["alarm_headroom_db"] == "1.9800"
    assert data["receiver_headroom_db"] == "8.9800"
    assert data["trend"]["sample_count"] == 96
    assert data["trend"]["slope_db_per_day"] == pytest.approx(-0.96, abs=0.000001)
    assert data["trend"]["crosses_low_alarm_7d"] is True
    # The unique key makes a repeated batch idempotent.
    client.post("/api/telemetry", json={"readings": readings})
    assert client.get("/api/telemetry/interfaces").json()["interfaces"][0]["observations"] == 103


def test_short_history_and_gap_do_not_make_forecast():
    client = TestClient(app)
    readings = series(102)
    assert client.post("/api/telemetry", json={"readings": readings}).status_code == 201
    assert client.get("/api/telemetry/interfaces/if-1/analysis").json()["trend"] is None
    late = series(1, start=datetime(2026, 1, 5, tzinfo=timezone.utc))[0]
    client.post("/api/telemetry", json={"readings": [late]})
    data = client.get("/api/telemetry/interfaces/if-1/analysis").json()
    assert data["consecutive_valid"] == 1
    assert data["trend"] is None


def test_status_and_timezone_validation():
    client = TestClient(app)
    row = series(1)[0]
    row["timestamp"] = "2026-01-01T00:00:00"
    assert client.post("/api/telemetry", json={"readings": [row]}).status_code == 422
    row["timestamp"] = "2026-01-01T00:00:00+00:00"
    row["status"] = "offline"
    row["rx_dbm"] = None
    assert client.post("/api/telemetry", json={"readings": [row]}).status_code == 201
    data = client.get("/api/telemetry/interfaces/if-1/analysis").json()
    assert data["rx_dbm"] is None and data["trend"] is None


def test_lower_cusum_requires_explicit_calibration_and_uses_recurrence():
    client = TestClient(app)
    readings = series(4, step=-0.5)
    assert client.post("/api/telemetry", json={"readings": readings}).status_code == 201
    path = "/api/telemetry/interfaces/if-1/analysis"
    assert client.get(path).json()["cusum"] is None
    assert client.get(path + "?reference_mean_dbm=-25").status_code == 400
    result = client.get(path + "?reference_mean_dbm=-25&allowance_db=0.1&decision_limit_db=1").json()["cusum"]
    # Deviations: 0, 0.5, 1.0, 1.5 dB. C = max(0, C + deviation - 0.1).
    assert result["current_cumulative_db"] == pytest.approx(2.7)
    assert result["crossed_limit"] is True
    assert result["first_crossing"] == readings[2]["timestamp"]
