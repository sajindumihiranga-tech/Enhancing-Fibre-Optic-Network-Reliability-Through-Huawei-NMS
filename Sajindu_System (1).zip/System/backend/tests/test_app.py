from io import BytesIO
from pathlib import Path

from fastapi.testclient import TestClient
from openpyxl import Workbook
import pytest

from app.core import band_for, parse_power, parse_workbook
from app.main import app


@pytest.fixture(autouse=True)
def database(tmp_path, monkeypatch):
    monkeypatch.setenv("NMS_DB_PATH", str(tmp_path / "test.sqlite3"))


def workbook(rows, header=("Tele Numbers", "Location", "Power level")):
    book = Workbook()
    sheet = book.active
    sheet.append(header)
    for row in rows:
        sheet.append(row)
    output = BytesIO()
    book.save(output)
    return output.getvalue()


@pytest.mark.parametrize(("power", "expected"), [
    ("-25 dBm", "reference"), ("-25.85 dBm", "buffer"),
    ("-27 dBm", "buffer"), ("-27.001 dBm", "watch"),
    ("-29.995 dBm", "watch"), ("-30 dBm", "priority"),
    ("-34 dBm", "urgent"), ("-38 dBm", "urgent"),
    ("-38.001 dBm", "very_low"), ("+2 dBm", "reference"),
])
def test_boundaries(power, expected):
    assert band_for(parse_power(power)) == expected


@pytest.mark.parametrize("power", ["", "N/A", "-25 volts", "-25dBm extra", "NaN dBm", "-Infinity dBm"])
def test_invalid_power(power):
    with pytest.raises(ValueError):
        parse_power(power)


def test_multi_file_import_reconciles_and_does_not_leak_identifiers():
    client = TestClient(app)
    a = workbook([("077000001", "A", "-25.85 dBm"), ("077000002", "B", "-70.52 dBm")])
    b = workbook([("077000003", "C", "-30 dBm"), ("077000004", "D", "bad")])
    response = client.post("/api/imports", files=[
        ("files", ("SYS1.xlsx", a, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")),
        ("files", ("SYS LOSS.xlsx", b, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")),
    ])
    assert response.status_code == 201
    data = response.json()
    assert (data["total_rows"], data["accepted"], data["rejected"]) == (4, 3, 1)
    assert data["counts"]["buffer"] == 1
    assert data["counts"]["priority"] == 1
    assert data["counts"]["very_low"] == 1
    assert data["sources"][1]["errors"] == [{"excel_row": 3, "reason": "Power must be a complete numeric value followed by dBm"}]
    assert "077000001" not in response.text
    assert client.get("/api/imports/latest").json()["import"]["id"] == data["id"]
    assert client.get(f"/api/imports/{data['id']}").json() == data
    review = client.get(f"/api/imports/{data['id']}/readings?band=very_low").json()
    assert review["total"] == 1
    assert review["readings"] == [{"filename": "SYS1.xlsx", "sheet": "Sheet", "excel_row": 3, "rx_dbm": "-70.52", "band": "very_low"}]
    assert "077000002" not in str(review)


def test_duplicate_across_files_is_rejected():
    client = TestClient(app)
    a = workbook([("id1", "A", "-20 dBm")])
    b = workbook([("id1", "B", "-22 dBm"), ("id2", "A", "-24 dBm")])
    response = client.post("/api/imports", files=[
        ("files", ("a.xlsx", a, "application/octet-stream")),
        ("files", ("b.xlsx", b, "application/octet-stream")),
    ])
    assert response.status_code == 201
    assert response.json()["accepted"] == 1
    assert response.json()["rejected"] == 2


def test_bad_schema_rejected_without_creating_import():
    client = TestClient(app)
    bad = workbook([("id1", "A", "-20 dBm")], header=("ID", "Location", "Power level"))
    assert client.post("/api/imports", files={"files": ("bad.xlsx", bad)}).status_code == 422
    assert client.get("/api/imports/latest").json() == {"import": None}


def test_blank_middle_row_is_audited():
    data = workbook([("id1", "A", "-20 dBm"), (None, None, None), ("id2", "B", "-30 dBm")])
    _, rows = parse_workbook(data)
    assert len(rows) == 3
    assert rows[1].excel_row == 3 and rows[1].error


def test_frontend_and_health():
    client = TestClient(app)
    assert client.get("/").status_code == 200
    assert "Import and analyse" in client.get("/").text
    assert client.get("/api/health").json()["status"] == "ok"


def test_original_report_workbooks_when_available():
    source = Path(__file__).resolve().parents[4]
    names = ("SYS LOSS.xlsx", "SYS QULITY.xlsx", "SYS1.xlsx")
    if not all((source / name).is_file() for name in names):
        pytest.skip("Original report workbooks are not present")
    files = [("files", (name, (source / name).read_bytes(), "application/octet-stream")) for name in names]
    result = TestClient(app).post("/api/imports", files=files)
    assert result.status_code == 201
    data = result.json()
    assert (data["total_rows"], data["accepted"], data["rejected"]) == (400, 400, 0)
    assert data["counts"] == {
        "reference": 193, "buffer": 11, "watch": 28,
        "priority": 27, "urgent": 12, "very_low": 129,
    }
    assert [source["total_rows"] for source in data["sources"]] == [100, 100, 200]
